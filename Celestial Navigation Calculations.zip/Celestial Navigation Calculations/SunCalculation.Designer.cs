﻿namespace Celestial_Navigation_Calculations
{
    partial class SunCalculation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bMainWindow = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bMainWindow
            // 
            this.bMainWindow.Location = new System.Drawing.Point(393, 408);
            this.bMainWindow.Name = "bMainWindow";
            this.bMainWindow.Size = new System.Drawing.Size(127, 30);
            this.bMainWindow.TabIndex = 0;
            this.bMainWindow.Text = "Main Window";
            this.bMainWindow.UseVisualStyleBackColor = true;
            this.bMainWindow.Click += new System.EventHandler(this.bMainWindow_Click);
            // 
            // SunCalculation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.bMainWindow);
            this.Name = "SunCalculation";
            this.Text = "Sun Calculation";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bMainWindow;
    }
}